#!/usr/bin/env python3
"""Sprint 3A — Fix compras-nueva.controller.js: pasar datos.pago al orquestador"""

filepath = '/root/mi_erp/src/controllers/compras-nueva.controller.js'
with open(filepath, 'r') as f:
    content = f.read()

original = content

# ═══════════════════════════════════════════════════════════════
# Agregar b.pago al objeto que se pasa a crearComprobanteCompleto
# Buscamos la última línea antes de cerrar el objeto:
#   total_comprobante: b.total_comprobante ? parseFloat(b.total_comprobante) : null
# Y le agregamos pago: b.pago || null
# ═══════════════════════════════════════════════════════════════

old_last_param = "            total_comprobante: b.total_comprobante ? parseFloat(b.total_comprobante) : null\n        });"

new_last_param = (
    "            total_comprobante: b.total_comprobante ? parseFloat(b.total_comprobante) : null,\n"
    "            // Paso 10: pago opcional (viene del modal de pago en compras.html)\n"
    "            pago: b.pago || null\n"
    "        });"
)

if old_last_param in content:
    content = content.replace(old_last_param, new_last_param, 1)
    print("✅ FIX: datos.pago agregado a llamada crearComprobanteCompleto")
else:
    print("⚠️  Patrón total_comprobante no encontrado — verificar manualmente")
    # Debug
    idx = content.find('total_comprobante')
    if idx >= 0:
        print("   → total_comprobante encontrado en posición " + str(idx))
        print("   → Contexto: " + repr(content[idx:idx+120]))
    else:
        print("   → total_comprobante NO encontrado en el archivo")

if content != original:
    with open(filepath, 'w') as f:
        f.write(content)
    print("✅ Archivo guardado: " + filepath)
else:
    print("⚠️  Sin cambios en " + filepath)
