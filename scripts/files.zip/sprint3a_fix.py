#!/usr/bin/env python3
"""Sprint 3A — Fix compras.helper.js: agregar paso 10 pago opcional"""

filepath = '/root/mi_erp/src/utils/compras.helper.js'
with open(filepath, 'r') as f:
    content = f.read()

original = content
fixes = 0

# ═══════════════════════════════════════════════════════════════
# FIX 1: Declarar cuentaPorPagar + capturar retorno de crearMovimientoCuenta
# ═══════════════════════════════════════════════════════════════

old_step7 = (
    "    // \u2500\u2500 7. Cuenta corriente (si tipo lo permite) \u2500\u2500\n"
    "    if (Number(tipo.afecta_cuenta) !== 0) {\n"
    "        // 7a. Cuentas por pagar (deuda con vencimiento)\n"
    "        const montoMovimiento = Math.abs(totales.total * tipo.afecta_cuenta);\n"
    "        const tipoMovimiento = tipo.afecta_cuenta > 0 ? 'compra' : 'nota_credito';\n"
    "        await crearMovimientoCuenta(client, {"
)

new_step7 = (
    "    // \u2500\u2500 7. Cuenta corriente (si tipo lo permite) \u2500\u2500\n"
    "    let cuentaPorPagar = null;\n"
    "    if (Number(tipo.afecta_cuenta) !== 0) {\n"
    "        // 7a. Cuentas por pagar (deuda con vencimiento)\n"
    "        const montoMovimiento = Math.abs(totales.total * tipo.afecta_cuenta);\n"
    "        const tipoMovimiento = tipo.afecta_cuenta > 0 ? 'compra' : 'nota_credito';\n"
    "        cuentaPorPagar = await crearMovimientoCuenta(client, {"
)

if old_step7 in content:
    content = content.replace(old_step7, new_step7, 1)
    fixes += 1
    print("✅ FIX 1: cuentaPorPagar declarada + retorno capturado")
else:
    print("⚠️  FIX 1: Patrón paso 7 no encontrado — verificar manualmente")

# ═══════════════════════════════════════════════════════════════
# FIX 2: Reemplazar return final con paso 10 + nuevo return
# ═══════════════════════════════════════════════════════════════

old_return = (
    "        await autoActualizarEstadoOrden(client, id_orden_compra, id_empresa);\n"
    "    }\n"
    "\n"
    "    return { id_comprobante, numero_completo: numeroCompleto };\n"
    "}"
)

PASO_10 = """        await autoActualizarEstadoOrden(client, id_orden_compra, id_empresa);
    }

    // ── 10. Pago inmediato (opcional — si datos.pago viene con formas_pago) ──
    // Permite que compras.html registre el pago en la misma transacción.
    // Si no viene datos.pago → queda como CC (comportamiento actual sin cambios).
    var resultadoPago = null;
    if (datos.pago && datos.pago.formas_pago && datos.pago.formas_pago.length > 0) {
        // Lazy require: evita dependencia circular compras↔pagos-proveedores
        var pagosProvHelper = require('./pagos-proveedores.helper');

        var totalPago = datos.pago.formas_pago.reduce(function(s, fp) {
            return s + parseFloat(fp.monto || 0);
        }, 0);

        // Si hay CxP recién creado, imputar el pago contra esa deuda
        var facturasAImputar = [];
        if (cuentaPorPagar && cuentaPorPagar.id_cuenta) {
            var montoImputar = Math.min(totalPago, parseFloat(cuentaPorPagar.saldo || cuentaPorPagar.monto));
            facturasAImputar.push({
                id_cuenta: cuentaPorPagar.id_cuenta,
                monto_a_pagar: montoImputar
            });
        }

        var esPagoACuenta = facturasAImputar.length === 0;

        resultadoPago = await pagosProvHelper.registrarPagoProveedorCompleto(client, {
            id_empresa: id_empresa,
            id_proveedor: id_proveedor,
            id_usuario: id_usuario,
            id_comprobante: id_comprobante,
            formas_pago: datos.pago.formas_pago,
            facturas_a_pagar: esPagoACuenta ? undefined : facturasAImputar,
            es_pago_a_cuenta: esPagoACuenta,
            observaciones: datos.pago.observaciones || null
        });
    }

    return {
        id_comprobante: id_comprobante,
        numero_completo: numeroCompleto,
        pago: resultadoPago
    };
}"""

if old_return in content:
    content = content.replace(old_return, PASO_10, 1)
    fixes += 1
    print("✅ FIX 2: Paso 10 (pago opcional) + return ampliado")
else:
    print("⚠️  FIX 2: Patrón return no encontrado — verificar manualmente")
    # Debug: mostrar lo que hay alrededor del return
    idx = content.find('return { id_comprobante, numero_completo: numeroCompleto }')
    if idx >= 0:
        print("   → El return existe en posición " + str(idx))
        print("   → Contexto: " + repr(content[max(0,idx-100):idx+60]))
    else:
        print("   → El return NO se encontró en el archivo")

if content != original:
    with open(filepath, 'w') as f:
        f.write(content)
    print("✅ " + str(fixes) + " fix(es) aplicados a: " + filepath)
    print("   Líneas: " + str(len(content.split('\n'))))
else:
    print("⚠️  Sin cambios en " + filepath)
