#!/bin/bash
set -e
ERP="/root/mi_erp"
BACKUP_DIR="$ERP/backups/pre_sprint3a_compras_$(date +%Y%m%d_%H%M%S)"

echo "═══════════════════════════════════════════════════════════════"
echo "FASE 0: BACKUP"
echo "═══════════════════════════════════════════════════════════════"
mkdir -p "$BACKUP_DIR"
cp "$ERP/src/utils/compras.helper.js" "$BACKUP_DIR/"
cp "$ERP/src/controllers/compras-nueva.controller.js" "$BACKUP_DIR/"
echo "✅ Backup en: $BACKUP_DIR"

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "FASE 1: compras.helper.js — Paso 10 pago opcional"
echo "═══════════════════════════════════════════════════════════════"

python3 /tmp/sprint3a_fix.py

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "FASE 2: compras-nueva.controller.js — Pasar datos.pago"
echo "═══════════════════════════════════════════════════════════════"

python3 /tmp/sprint3a_ctrl.py

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "FASE 3: RESTART + VERIFICACIÓN"
echo "═══════════════════════════════════════════════════════════════"
source ~/.nvm/nvm.sh
pm2 restart erplago
sleep 3

echo ""
echo "—— PM2 status:"
pm2 ls --no-color | grep erplago

echo ""
echo "—— Verificar paso 10 existe en helper:"
grep -n "Paso 10\|Pago inmediato\|pagosProvHelper\|resultadoPago" "$ERP/src/utils/compras.helper.js"

echo ""
echo "—— Verificar controller pasa datos.pago:"
grep -n "pago:" "$ERP/src/controllers/compras-nueva.controller.js" | head -5

echo ""
echo "—— Contar líneas:"
echo "   Helper:     $(wc -l < $ERP/src/utils/compras.helper.js) líneas"
echo "   Controller: $(wc -l < $ERP/src/controllers/compras-nueva.controller.js) líneas"

echo ""
echo "—— Test sin pago (debe funcionar igual que antes):"
TOKEN=$(curl -s -X POST http://localhost:3000/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"juan","password":"jp191082"}' | python3 -c "import sys,json; print(json.load(sys.stdin).get('token',''))")
if [ -n "$TOKEN" ]; then
    echo "Token ✅"
    RES=$(curl -s http://localhost:3000/api/compras-nueva/form-data \
      -H "Authorization: Bearer $TOKEN")
    echo "$RES" | python3 -c "
import sys, json
d = json.load(sys.stdin)
if d.get('success'):
    print('✅ form-data OK: ' + str(len(d['data']['tipos'])) + ' tipos, ' + str(len(d['data']['formasPago'])) + ' formas pago')
else:
    print('❌ Error: ' + str(d))
"
fi

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "SPRINT 3A COMPLETADO"
echo "═══════════════════════════════════════════════════════════════"
echo "Backup: $BACKUP_DIR"
echo ""
echo "Resumen:"
echo "  compras.helper.js: +paso 10 pago opcional en crearComprobanteCompleto()"
echo "  compras-nueva.controller.js: pasa b.pago al orquestador"
echo ""
echo "Para RESTAURAR:"
echo "  cp $BACKUP_DIR/compras.helper.js $ERP/src/utils/"
echo "  cp $BACKUP_DIR/compras-nueva.controller.js $ERP/src/controllers/"
echo "  source ~/.nvm/nvm.sh && pm2 restart erplago"
