#!/usr/bin/env python3
"""Sprint 3B — Modificar compras.js: modal de pago + enviar separado"""

filepath = '/root/mi_erp/frontend/js/compras.js'
with open(filepath, 'r') as f:
    content = f.read()

original = content

if 'mostrarModalPago' in content:
    print("⚠️  Funciones de modal ya existen — saltando modificación JS")
    exit(0)

# ═══════════════════════════════════════════════════════════════
# PASO 1: Reemplazar guardarComprobante() completa
# ═══════════════════════════════════════════════════════════════

OLD_FUNC = '''async function guardarComprobante() {
    if (guardando) return;
    if (!proveedorSeleccionado) { toast('Seleccione un proveedor (F3)', 'warning'); document.getElementById('inputProv').focus(); return; }
    var id_tipo = document.getElementById('selTipo').value;
    if (!id_tipo) { toast('Seleccione tipo de comprobante', 'warning'); document.getElementById('selTipo').focus(); return; }
    var pv = (document.getElementById('inputPV') || {}).value || '';
    var num = (document.getElementById('inputNumero') || {}).value || '';
    if (!pv.trim() || !num.trim()) { toast('Ingrese punto de venta y número', 'warning'); return; }
    var fecha = document.getElementById('inputFechaEmision').value;
    if (!fecha) { toast('Ingrese fecha de emisión', 'warning'); return; }
    if (itemsComprobante.length === 0) { toast('Agregue al menos un item', 'warning'); document.getElementById('inputProd').focus(); return; }

    for (var i = 0; i < itemsComprobante.length; i++) {
        var it = itemsComprobante[i];
        if (!it.nombre && !it.id_producto) { toast('Item ' + (i + 1) + ': falta descripción', 'warning'); focusCell(i, 2); return; }
        if (it.cantidad < 1) { toast('Item ' + (i + 1) + ': cantidad inválida', 'warning'); focusCell(i, 1); return; }
    }

    var btn = document.getElementById('btnGuardar');
    guardando = true;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Guardando...';

    try {
        var datos = {
            id_proveedor: proveedorSeleccionado.id_proveedor,
            id_tipo: parseInt(id_tipo),
            punto_venta: pv.trim(),
            numero_comprobante: num.trim(),
            fecha_emision: fecha,
            fecha_vencimiento: (document.getElementById('inputFechaVto') || {}).value || null,
            items: itemsComprobante.map(function(it) {
                return {
                    id_producto: it.id_producto,
                    descripcion: it.nombre || it.descripcion,
                    cantidad: it.cantidad,
                    precio_unitario: it.precio_unitario,
                    descuento_porcentaje: it.descuento_porcentaje || 0,
                    descuento_monto: it.descuento_monto || 0,
                    descuentos_compuestos: it.descuentos_compuestos || null,
                    iva_porcentaje: it.iva_porcentaje || 21,
                    id_alicuota: it.id_alicuota,
                    afecta_stock: it.afecta_stock !== false
                };
            }),
            percepcion_iva: parseFloat(document.getElementById('inputPercIVA').value) || 0,
            percepcion_iibb: parseFloat(document.getElementById('inputPercIIBB').value) || 0,
            percepcion_iibb_jurisdiccion: (document.getElementById('inputJurisd') || {}).value || null,
            impuestos_internos: parseFloat(document.getElementById('inputImpInt').value) || 0,
            afecta_stock: document.getElementById('chkStock').checked !== false,
            actualizar_precios: document.getElementById('chkPrecios').checked || false,
            nc_devuelve_mercaderia: document.getElementById('chkNCDev').checked || false,
            id_moneda: parseInt(document.getElementById('selMoneda').value) || 1,
            cotizacion: parseFloat(document.getElementById('inputCotiz').value) || 1,
            total_comprobante: parseFloat(document.getElementById('inputTotalComp').value) || null,
            observaciones: (document.getElementById('inputObs') || {}).value || null
        };

        var r = await apiFetch('/compras-nueva', { method: 'POST', body: JSON.stringify(datos) });
        toast(r.data.numero_completo + ' guardado correctamente', 'success');

        setTimeout(function() {
            if (confirm('¿Cargar otro comprobante del mismo proveedor?')) {
                limpiarMantenerProveedor();
            } else {
                switchTab('listado');
                cargarListado();
            }
        }, 500);

    } catch (e) {
        toast(e.message, 'danger');
    } finally {
        guardando = false;
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-check-lg"></i> GUARDAR <span class="kbd">F2</span>';
    }
}'''

NEW_FUNC = '''// ═══════════════════════════════════════════════════════════════
// GUARDAR COMPROBANTE — Ahora muestra modal de pago antes de enviar
// ═══════════════════════════════════════════════════════════════

var _datosComprobantePendiente = null;
var _modalPagoInstance = null;
var _formasPagoModal = [];

// Fallback: si formatMoney no existe, usar formateo básico
if (typeof formatMoney !== 'function') {
    var formatMoney = function(v) { return '$' + (parseFloat(v) || 0).toLocaleString('es-AR', {minimumFractionDigits: 2, maximumFractionDigits: 2}); };
}

async function guardarComprobante() {
    if (guardando) return;
    if (!proveedorSeleccionado) { toast('Seleccione un proveedor (F3)', 'warning'); document.getElementById('inputProv').focus(); return; }
    var id_tipo = document.getElementById('selTipo').value;
    if (!id_tipo) { toast('Seleccione tipo de comprobante', 'warning'); document.getElementById('selTipo').focus(); return; }
    var pv = (document.getElementById('inputPV') || {}).value || '';
    var num = (document.getElementById('inputNumero') || {}).value || '';
    if (!pv.trim() || !num.trim()) { toast('Ingrese punto de venta y número', 'warning'); return; }
    var fecha = document.getElementById('inputFechaEmision').value;
    if (!fecha) { toast('Ingrese fecha de emisión', 'warning'); return; }
    if (itemsComprobante.length === 0) { toast('Agregue al menos un item', 'warning'); document.getElementById('inputProd').focus(); return; }

    for (var i = 0; i < itemsComprobante.length; i++) {
        var it = itemsComprobante[i];
        if (!it.nombre && !it.id_producto) { toast('Item ' + (i + 1) + ': falta descripción', 'warning'); focusCell(i, 2); return; }
        if (it.cantidad < 1) { toast('Item ' + (i + 1) + ': cantidad inválida', 'warning'); focusCell(i, 1); return; }
    }

    _datosComprobantePendiente = {
        id_proveedor: proveedorSeleccionado.id_proveedor,
        id_tipo: parseInt(id_tipo),
        punto_venta: pv.trim(),
        numero_comprobante: num.trim(),
        fecha_emision: fecha,
        fecha_vencimiento: (document.getElementById('inputFechaVto') || {}).value || null,
        items: itemsComprobante.map(function(it) {
            return {
                id_producto: it.id_producto,
                descripcion: it.nombre || it.descripcion,
                cantidad: it.cantidad,
                precio_unitario: it.precio_unitario,
                descuento_porcentaje: it.descuento_porcentaje || 0,
                descuento_monto: it.descuento_monto || 0,
                descuentos_compuestos: it.descuentos_compuestos || null,
                iva_porcentaje: it.iva_porcentaje || 21,
                id_alicuota: it.id_alicuota,
                afecta_stock: it.afecta_stock !== false
            };
        }),
        percepcion_iva: parseFloat(document.getElementById('inputPercIVA').value) || 0,
        percepcion_iibb: parseFloat(document.getElementById('inputPercIIBB').value) || 0,
        percepcion_iibb_jurisdiccion: (document.getElementById('inputJurisd') || {}).value || null,
        impuestos_internos: parseFloat(document.getElementById('inputImpInt').value) || 0,
        afecta_stock: document.getElementById('chkStock').checked !== false,
        actualizar_precios: document.getElementById('chkPrecios').checked || false,
        nc_devuelve_mercaderia: document.getElementById('chkNCDev').checked || false,
        id_moneda: parseInt(document.getElementById('selMoneda').value) || 1,
        cotizacion: parseFloat(document.getElementById('inputCotiz').value) || 1,
        total_comprobante: parseFloat(document.getElementById('inputTotalComp').value) || null,
        observaciones: (document.getElementById('inputObs') || {}).value || null
    };

    mostrarModalPago();
}

// ═══════════════════════════════════════════════════════════════
// MODAL DE PAGO — Funciones
// ═══════════════════════════════════════════════════════════════

function mostrarModalPago() {
    var total = calcularTotalActual();
    var tipoSel = (formData.tipos || []).find(function(t) { return t.id_tipo == _datosComprobantePendiente.id_tipo; });
    var numCompleto = (tipoSel ? tipoSel.codigo : '') + ' ' +
        (_datosComprobantePendiente.punto_venta || '').padStart(4, '0') + '-' +
        (_datosComprobantePendiente.numero_comprobante || '').padStart(8, '0');

    document.getElementById('mpNumero').textContent = numCompleto;
    document.getElementById('mpTotal').textContent = formatMoney(total);
    document.getElementById('mpProveedor').textContent = proveedorSeleccionado ? proveedorSeleccionado.razon_social : '—';

    _formasPagoModal = [];
    agregarFPModal();

    if (!_modalPagoInstance) {
        _modalPagoInstance = new bootstrap.Modal(document.getElementById('modalPagoCompra'), { keyboard: false });
    }
    _modalPagoInstance.show();

    setTimeout(function() {
        var primerMonto = document.querySelector('#mpListaFP input[type="number"]');
        if (primerMonto) { primerMonto.value = total.toFixed(2); primerMonto.select(); primerMonto.focus(); }
        actualizarTotalesPago();
    }, 300);
}

function agregarFPModal() {
    var fpActivas = (formData.formasPago || []).filter(function(fp) { return fp.activo; });
    var idx = _formasPagoModal.length;
    _formasPagoModal.push({ id_forma_pago: fpActivas.length > 0 ? fpActivas[0].id_forma_pago : 1, monto: 0, tipo: fpActivas.length > 0 ? fpActivas[0].tipo : 'efectivo' });
    renderFPModal();
}

function eliminarFPModal(idx) {
    _formasPagoModal.splice(idx, 1);
    renderFPModal();
    actualizarTotalesPago();
}

function renderFPModal() {
    var container = document.getElementById('mpListaFP');
    var fpActivas = (formData.formasPago || []).filter(function(fp) { return fp.activo; });
    var html = '';
    for (var i = 0; i < _formasPagoModal.length; i++) {
        var fp = _formasPagoModal[i];
        html += '<div class="mp-fp-row">';
        html += '<div class="form-group" style="flex:2"><label>Forma de pago</label>';
        html += '<select onchange="cambiarFPModal(' + i + ', this)">';
        for (var j = 0; j < fpActivas.length; j++) {
            var sel = fpActivas[j].id_forma_pago == fp.id_forma_pago ? ' selected' : '';
            html += '<option value="' + fpActivas[j].id_forma_pago + '" data-tipo="' + (fpActivas[j].tipo || '') + '"' + sel + '>' + fpActivas[j].nombre + '</option>';
        }
        html += '</select></div>';
        html += '<div class="form-group" style="flex:1"><label>Monto</label>';
        html += '<input type="number" step="0.01" value="' + (fp.monto || '') + '" onchange="actualizarMontoFP(' + i + ', this.value)" onfocus="this.select()" style="text-align:right;font-weight:600"></div>';
        if (_formasPagoModal.length > 1) {
            html += '<button class="btn-del btn-del" onclick="eliminarFPModal(' + i + ')" title="Quitar"><i class="bi bi-x-circle"></i></button>';
        }
        html += '</div>';
    }
    container.innerHTML = html;
}

function cambiarFPModal(idx, sel) {
    _formasPagoModal[idx].id_forma_pago = parseInt(sel.value);
    var opt = sel.options[sel.selectedIndex];
    _formasPagoModal[idx].tipo = opt.getAttribute('data-tipo') || 'efectivo';
}

function actualizarMontoFP(idx, valor) {
    _formasPagoModal[idx].monto = parseFloat(valor) || 0;
    actualizarTotalesPago();
}

function actualizarTotalesPago() {
    var total = calcularTotalActual();
    var totalFP = 0;
    for (var i = 0; i < _formasPagoModal.length; i++) {
        totalFP += parseFloat(_formasPagoModal[i].monto) || 0;
    }
    var resto = total - totalFP;

    document.getElementById('mpTotalFP').textContent = formatMoney(totalFP);
    var restoEl = document.getElementById('mpRestoCC');
    restoEl.textContent = formatMoney(Math.max(0, resto));
    restoEl.style.color = resto > 0.01 ? 'var(--danger)' : 'var(--success)';

    var btnPagar = document.getElementById('mpBtnPagar');
    if (totalFP <= 0.001) {
        btnPagar.disabled = true;
        btnPagar.innerHTML = '<i class="bi bi-check-lg"></i> Ingrese monto';
    } else if (totalFP > total + 0.01) {
        btnPagar.disabled = true;
        btnPagar.innerHTML = '<i class="bi bi-exclamation-triangle"></i> Excede total';
    } else {
        btnPagar.disabled = false;
        if (resto > 0.01) {
            btnPagar.innerHTML = '<i class="bi bi-check-lg"></i> Pago parcial + CC <span class="kbd">F2</span>';
        } else {
            btnPagar.innerHTML = '<i class="bi bi-check-lg"></i> Confirmar pago <span class="kbd">F2</span>';
        }
    }
}

function calcularTotalActual() {
    var el = document.getElementById('resTotalCalc');
    if (!el) return 0;
    var txt = el.textContent.replace(/[^0-9,.-]/g, '').replace(/\./g, '').replace(',', '.');
    return parseFloat(txt) || 0;
}

// ═══════════════════════════════════════════════════════════════
// ENVIAR — Con o sin pago
// ═══════════════════════════════════════════════════════════════

async function enviarComoCC() {
    if (_modalPagoInstance) _modalPagoInstance.hide();
    await enviarComprobante(null);
}

async function confirmarPagoModal() {
    var totalFP = 0;
    var formasValidas = [];
    for (var i = 0; i < _formasPagoModal.length; i++) {
        var fp = _formasPagoModal[i];
        var monto = parseFloat(fp.monto) || 0;
        if (monto > 0) {
            formasValidas.push({
                id_forma_pago: fp.id_forma_pago,
                monto: monto,
                tipo: fp.tipo || 'efectivo',
                id_moneda: 1
            });
            totalFP += monto;
        }
    }
    if (formasValidas.length === 0) {
        toast('Ingrese al menos un monto', 'warning');
        return;
    }
    var total = calcularTotalActual();
    if (totalFP > total + 0.01) {
        toast('El monto de pago excede el total del comprobante', 'warning');
        return;
    }

    if (_modalPagoInstance) _modalPagoInstance.hide();

    var pagoData = {
        formas_pago: formasValidas,
        observaciones: null
    };
    await enviarComprobante(pagoData);
}

async function enviarComprobante(pagoData) {
    if (!_datosComprobantePendiente) { toast('Error interno: sin datos pendientes', 'danger'); return; }

    var btn = document.getElementById('btnGuardar');
    guardando = true;
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Guardando...';

    try {
        var datos = _datosComprobantePendiente;
        if (pagoData) {
            datos.pago = pagoData;
        }

        var r = await apiFetch('/compras-nueva', { method: 'POST', body: JSON.stringify(datos) });

        var msg = r.data.numero_completo + ' guardado';
        if (r.data.pago) {
            msg += ' + Pago #' + r.data.pago.numero_pago + ' registrado';
        } else {
            msg += ' (pendiente en CC)';
        }
        toast(msg, 'success');

        _datosComprobantePendiente = null;

        setTimeout(function() {
            if (confirm('¿Cargar otro comprobante del mismo proveedor?')) {
                limpiarMantenerProveedor();
            } else {
                switchTab('listado');
                cargarListado();
            }
        }, 500);

    } catch (e) {
        toast(e.message, 'danger');
    } finally {
        guardando = false;
        btn.disabled = false;
        btn.innerHTML = '<i class="bi bi-check-lg"></i> GUARDAR <span class="kbd">F2</span>';
    }
}

function cerrarModalPago() {
    if (_modalPagoInstance) _modalPagoInstance.hide();
    _datosComprobantePendiente = null;
}

// Interceptar F2 dentro del modal para confirmar pago
document.addEventListener('keydown', function(e) {
    var modal = document.getElementById('modalPagoCompra');
    if (modal && modal.classList.contains('show')) {
        if (e.key === 'F2') { e.preventDefault(); e.stopPropagation(); confirmarPagoModal(); }
        if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); }
    }
}, true);'''


if OLD_FUNC in content:
    content = content.replace(OLD_FUNC, NEW_FUNC, 1)
    print("✅ guardarComprobante() reemplazada con versión modal de pago")
    print("   + mostrarModalPago, agregarFPModal, confirmarPagoModal, enviarComoCC, enviarComprobante")
else:
    print("❌ No se encontró guardarComprobante() — verificar manualmente")
    idx = content.find('async function guardarComprobante')
    if idx >= 0:
        print("   → La función existe en posición " + str(idx))
        snippet = content[idx:idx+200]
        print("   → Primeros 200 chars: " + repr(snippet))
    else:
        print("   → La función NO existe en el archivo")

if content != original:
    with open(filepath, 'w') as f:
        f.write(content)
    print("✅ Archivo guardado: " + filepath)
    print("   Líneas: " + str(len(content.split('\n'))))
else:
    print("⚠️  Sin cambios")
