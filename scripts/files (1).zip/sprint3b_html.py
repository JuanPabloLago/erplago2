#!/usr/bin/env python3
"""Sprint 3B — Inyectar modal de pago en compras.html"""

filepath = '/root/mi_erp/frontend/compras.html'
with open(filepath, 'r') as f:
    content = f.read()

if 'modalPagoCompra' in content:
    print("⚠️  Modal ya existe — saltando inyección HTML")
    exit(0)

MODAL_HTML = '''
<!-- ══════ MODAL PAGO AL CONFIRMAR COMPROBANTE ══════ -->
<div class="modal fade" id="modalPagoCompra" tabindex="-1" data-bs-backdrop="static">
<div class="modal-dialog modal-lg">
<div class="modal-content" style="border:2px solid var(--lago-500)">
    <div class="modal-header" style="background:var(--lago-700);color:#fff;padding:8px 16px">
        <h6 class="modal-title" style="margin:0"><i class="bi bi-cash-stack me-1"></i> Comprobante guardado — <span id="mpNumero"></span></h6>
    </div>
    <div class="modal-body" style="padding:12px 16px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;padding:10px;background:var(--lago-50);border-radius:6px">
            <div>
                <div style="font-size:.75rem;color:var(--text-muted)">TOTAL COMPROBANTE</div>
                <div style="font-size:1.6rem;font-weight:700;color:var(--lago-800)" id="mpTotal">$0,00</div>
            </div>
            <div style="text-align:right">
                <div style="font-size:.75rem;color:var(--text-muted)">PROVEEDOR</div>
                <div style="font-weight:600" id="mpProveedor">—</div>
            </div>
        </div>

        <!-- FORMAS DE PAGO -->
        <div id="mpFormasPagoSection">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
                <span style="font-weight:600;font-size:.85rem"><i class="bi bi-wallet2 me-1"></i>Formas de pago</span>
                <button class="btn-sec" style="font-size:.72rem;padding:2px 8px" onclick="agregarFPModal()"><i class="bi bi-plus"></i> Agregar</button>
            </div>
            <div id="mpListaFP"></div>
        </div>

        <!-- RESUMEN -->
        <div style="margin-top:12px;padding:10px;border:1px solid var(--border);border-radius:6px;background:#fafafa">
            <div style="display:flex;justify-content:space-between;font-size:.85rem;margin-bottom:4px">
                <span>Total formas de pago:</span>
                <span style="font-weight:700" id="mpTotalFP">$0,00</span>
            </div>
            <div style="display:flex;justify-content:space-between;font-size:.85rem">
                <span>Resta a Cuenta Corriente:</span>
                <span style="font-weight:700;color:var(--danger)" id="mpRestoCC">$0,00</span>
            </div>
        </div>
    </div>
    <div class="modal-footer" style="padding:8px 16px;display:flex;gap:8px;justify-content:space-between">
        <button class="btn-sec" style="font-size:.82rem" onclick="enviarComoCC()" id="mpBtnCC">
            <i class="bi bi-wallet2"></i> Todo a Cuenta Corriente
        </button>
        <div style="display:flex;gap:8px">
            <button class="btn-sec" onclick="cerrarModalPago()" style="font-size:.82rem">
                <i class="bi bi-x"></i> Cancelar
            </button>
            <button class="btn-guardar" style="font-size:.85rem;padding:6px 16px" onclick="confirmarPagoModal()" id="mpBtnPagar">
                <i class="bi bi-check-lg"></i> Confirmar Pago <span class="kbd">F2</span>
            </button>
        </div>
    </div>
</div>
</div>
</div>

<style>
.mp-fp-row{display:flex;gap:8px;align-items:end;margin-bottom:8px;padding:8px;background:#fff;border:1px solid var(--border);border-radius:4px}
.mp-fp-row .form-group{margin:0}
.mp-fp-row .form-group label{font-size:.65rem;font-weight:600;color:var(--text-muted);text-transform:uppercase;display:block;margin-bottom:1px}
.mp-fp-row .form-group input,.mp-fp-row .form-group select{padding:4px 6px;font-size:.85rem;border:1px solid var(--border);border-radius:3px}
.mp-fp-row .btn-del{align-self:center}
</style>
'''

# Inyectar antes del cierre </body>
marker = '</body>'
if marker in content:
    content = content.replace(marker, MODAL_HTML + '\n' + marker, 1)
    with open(filepath, 'w') as f:
        f.write(content)
    print("✅ Modal HTML inyectado en compras.html")
    print("   Líneas: " + str(len(content.split('\n'))))
else:
    # Intentar antes de </html>
    marker2 = '</html>'
    if marker2 in content:
        content = content.replace(marker2, MODAL_HTML + '\n' + marker2, 1)
        with open(filepath, 'w') as f:
            f.write(content)
        print("✅ Modal HTML inyectado antes de </html>")
    else:
        print("❌ No se encontró </body> ni </html>")
