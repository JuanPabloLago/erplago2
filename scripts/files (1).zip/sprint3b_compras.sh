#!/bin/bash
set -e
ERP="/root/mi_erp"
BACKUP_DIR="$ERP/backups/pre_sprint3b_compras_$(date +%Y%m%d_%H%M%S)"

echo "═══════════════════════════════════════════════════════════════"
echo "FASE 0: BACKUP"
echo "═══════════════════════════════════════════════════════════════"
mkdir -p "$BACKUP_DIR"
cp "$ERP/frontend/compras.html" "$BACKUP_DIR/"
cp "$ERP/frontend/js/compras.js" "$BACKUP_DIR/"
echo "✅ Backup en: $BACKUP_DIR"

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "FASE 1: Inyectar modal HTML en compras.html"
echo "═══════════════════════════════════════════════════════════════"
python3 /tmp/sprint3b_html.py

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "FASE 2: Modificar compras.js — modal pago + enviar separado"
echo "═══════════════════════════════════════════════════════════════"
python3 /tmp/sprint3b_js.py

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "FASE 3: RESTART + VERIFICACIÓN"
echo "═══════════════════════════════════════════════════════════════"
source ~/.nvm/nvm.sh
pm2 restart erplago
sleep 3

echo ""
echo "—— PM2 status:"
pm2 ls --no-color | grep erplago

echo ""
echo "—— Modal HTML inyectado:"
grep -c "modalPagoCompra" "$ERP/frontend/compras.html" && echo "✅ Modal encontrado" || echo "❌ Modal NO encontrado"

echo ""
echo "—— Funciones JS inyectadas:"
grep -n "mostrarModalPago\|enviarComprobante\|agregarFPModal\|confirmarPagoModal\|enviarComoCC" "$ERP/frontend/js/compras.js" | head -10

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "SPRINT 3B COMPLETADO"
echo "═══════════════════════════════════════════════════════════════"
echo "Backup: $BACKUP_DIR"
echo ""
echo "Para RESTAURAR:"
echo "  cp $BACKUP_DIR/compras.html $ERP/frontend/"
echo "  cp $BACKUP_DIR/compras.js $ERP/frontend/js/"
echo "  source ~/.nvm/nvm.sh && pm2 restart erplago"
